package phase2junit.phase2junit;

import org.junit.Test;

public class TestAnnotationDemo1 {
	
	// use Junit @Test annotation to exeucte your test methods
	
	@Test
	public void method1()
	{
		System.out.println("Hello Junit");
	}
}

