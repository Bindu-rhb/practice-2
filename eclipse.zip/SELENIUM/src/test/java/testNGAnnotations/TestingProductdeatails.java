package testNGAnnotations;

import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;
public class TestingProductdeatails {
	
	@Test
	public void findProductdetails()
	{
		String expectedProductType = "pencil";
		
		ProductSearch ps = new ProductSearch();
		
		Map<String, String> actualProductType = ps.getproductdetails();
		
		System.out.println(actualProductType);
		
		Assert.assertEquals(actualProductType, expectedProductType);
		
	}
	
	@Test
	public void findproductdetailswithEmptyInput()
	{
		try {
		ProductSearch ps = new ProductSearch();
		
		ps.getproductType(null);
		
		}
		catch(NullPointerException e1)
		{
		System.out.println("product name should not be empty");
		}
	}
	
	
	@Test
	public void invalidproductdetails()
	{
		try {
		ProductSearch ps = new ProductSearch();
		ps.getproductType(null);
		}
		catch (NullPointerException e1)
		{
			System.out.println("product details doesnot exist");
		}
		
	}
		
	
}

