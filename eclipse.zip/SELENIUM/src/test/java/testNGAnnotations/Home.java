package testNGAnnotations;

import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(test.testing.ListenersTest.class)

     public class Home extends Baseclass {
	
	  @Test
	  public void clickOnCategory()
	  {
		By driver;
		driver.findElement((SearchContext) By.xpath("//div[@id='navigation']/a[1]")).click();
		System.out.println("Clicked on links");
	  }
	
}

