package testNGAnnotations;

import org.testng.TestNG;

public class TestRunner {

    public static void main(String[] args) {
        TestNG testng = new TestNG();
        testng.setTestClasses(new Class[]{path.to.BookingTest.class});
        testng.setXmlSuites(Collections.singletonList(new File("path/to/testng.xml")));
        testng.run();
    }
}

