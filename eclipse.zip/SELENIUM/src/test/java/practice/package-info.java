package practice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class prac1 {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver(); 
		
		driver.get("https://www.selenium.dev/"); 
		driver.close(); 
	}
}