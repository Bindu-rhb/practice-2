package setup;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class SetUpCheck {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Use selenium to  open Chrome browser
		
		// WebDriver ==> It is an Interface --> has methods releated to testing on every browser
		// for every browser in selenium we have its corresponding browser class
		// the WebDriver interface methods are implemented in repective browser class
		// Classes are : ChromeDriver , FireFoxDriver,EdgeDriver,InternetExploerDriver
		// driver is an object
		
		WebDriver driver = new ChromeDriver(); // will open chrome browser on your local machine.
		// Selenium webdriver gives us many methods to test on browsers
		// enter the URL on the browser and open it
		
		driver.get("https://www.selenium.dev/"); // this get(URL) method will load the URL on the current browser
		
		// after testing is done close the browser
		
		driver.close(); //Closes the current browser window
	}
}


