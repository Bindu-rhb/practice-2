package setup;

public class CVV {
	public static void main(String[] args) {
	    int num1 = 0;
	    int num2 = 0;

	    for (int var = 0; var < 5; var++) {
	        if ((++num1 > 2) && (++num2 > 2)) {
	            num1++;
	        }
	    }

	    System.out.println(num1 + " and " + num2);
	}

}
