
/*public class Student {
	public String aName;
	public char grade;
	

	public static  void main(String[] args) { 
		Student S = new Student();
		System.out.println(" (" + S.aName +":"+S.grade + ")");
				// TODO Auto-generated method stub

		int pointer
	}

} */public class Student {
public static void main(String[] args) {
    int pointer = 0;
    int value = 1;
    
    while (true) {
        ++pointer;

        if (pointer % 2 == 0) {
            continue;
        } else if (pointer % 5 == 0) {
            break;
        }

        value *= 3;
        System.out.println(value);
    }
}}