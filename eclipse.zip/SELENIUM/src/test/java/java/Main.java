package java;

public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

    System.out.print("Enter a 3-character string: ");
    String string = scanner.next();

    if (string.length() != 3) {
        System.out.println("Invalid input: Please enter a 3-character string.");
    } else {
        boolean isUppercase = true;
        for (char c : string.toCharArray()) {
            if (!Character.isUpperCase(c)) {
                isUppercase = false;
                break;
            }
        }

        if (isUppercase) {
            System.out.println("The string consists only of uppercase letters.");
        } else {
            System.out.println("The string does not consist only of uppercase letters.");
        }
    }
}