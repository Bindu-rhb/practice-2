package RUNNERFILEs;
@RunWith(Cucumber.class)
@CucumberOptions(
		features="C:\\Users\\sreenu\\eclipse-workspace\\PHASE2CUCUMBER\\src\\main\\java\\FEATURES\\phase2.feature",
		glue = {"steps"},
		plugin= {"pretty","html:target/cucumberreport.html"}
		
		)
public class TestRunner {
	
	// we dont write anything over here.
	
}
