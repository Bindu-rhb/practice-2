$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"7ca4d0d2-ca11-41fd-8042-2d1e507631b6","feature":"Register multiple users on the Rediff account Page","scenario":"Test rediff Register Account Page","start":1706616715486,"group":1,"content":"","tags":"","end":1706616745555,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[#1,main,5,main]"}]);
});